
// DreamCandies_File_ToolDlg.h : header file
//

#pragma once
#include "CGridListCtrlGroups.h"


// CDreamCandies_File_ToolDlg dialog
class CDreamCandies_File_ToolDlg : public CDialogEx
{
// Construction
public:
	CDreamCandies_File_ToolDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_DREAMCANDIES_FILE_TOOL_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;
	CGridListCtrlGroups m_customerListCtrl;
	CFont* m_headerFont;
	CImageList m_imageList;
	CString m_folderPath;
	// Generated message map functions

	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedButtonBrowse();

	DECLARE_MESSAGE_MAP()

private:
	int m_sampleCount;
	int m_totalItemCount;
	void initializeColumnList();
	
	
public:
	void UpdateCustomerData();
	afx_msg void OnEnChangeEditSample();
};

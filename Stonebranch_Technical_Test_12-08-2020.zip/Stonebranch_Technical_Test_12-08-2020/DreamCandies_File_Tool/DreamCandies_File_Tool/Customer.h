#pragma once
#include <string>
#include <vector>

class Invoice;
class Customer
{
	std::string m_customerCode;
	std::string m_firstName;
	std::string m_lastName;
	std::vector<Invoice*>m_invoiceVect;
public:
	Customer();
	~Customer();

	void SetCustomerCode(std::string customerCode);

	void SetFirstName(std::string firstName);

	void SetLastName(std::string lastName);

	std::string GetCustomerCode()const;

	void AddInvoice(Invoice* pInvoice);

	void GetInvoiceVect(std::vector<Invoice*>& invoiceVect);

	std::string GetFirstName();

	std::string GetLastName();
};


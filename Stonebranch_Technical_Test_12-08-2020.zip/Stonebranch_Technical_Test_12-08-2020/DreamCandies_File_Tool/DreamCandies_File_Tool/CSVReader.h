#pragma once
#include <vector> 
class Customer;
class Invoice;
class InvoiceItem;
class CCSVReader
{
	Customer *m_pCustomer;
	Invoice *m_pInvoice;
	InvoiceItem *m_pInvoiceItem;
	CString m_customerPath;
	CString m_invoicePath;
	CString m_invoiceItemPath;
	int m_customerIndex;
	int m_invoiceIndex;
public:
	CCSVReader(CString customerPath, CString invoicePath, CString invoiceItemPath);
	~CCSVReader();
	void ReadCustomerCSVFile();
	void ReadInvoiceCSVFile();
	void ReadInvoiceItemCSVFile();

};


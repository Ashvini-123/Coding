// FileBrowserDlg.cpp : implementation file
//

#include "stdafx.h"
#include "DreamCandies_File_Tool.h"
#include "FileBrowserDlg.h"
#include "CSVReader.h"
#include "DreamCandies_File_ToolDlg.h"

// CFileBrowserDlg dialog

IMPLEMENT_DYNAMIC(CFileBrowserDlg, CDialogEx)

CFileBrowserDlg::CFileBrowserDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CFileBrowserDlg::IDD, pParent)
	, m_customerPath(_T(""))
	, m_invoicePath(_T(""))
	, m_invoiceItemPath(_T(""))
{
	if (m_fileTool)
		delete m_fileTool;
	m_fileTool = nullptr;
}

CFileBrowserDlg::~CFileBrowserDlg()
{
}

void CFileBrowserDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_CUSTOMER_CSV, m_customerPath);
	DDX_Text(pDX, IDC_EDIT_INVOICE_CSV, m_invoicePath);
	DDX_Text(pDX, IDC_EDIT_INVOICE_ITEM, m_invoiceItemPath);
}


BEGIN_MESSAGE_MAP(CFileBrowserDlg, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON_CUSTOMER, &CFileBrowserDlg::OnBnClickedButtonCustomer)
	ON_BN_CLICKED(IDC_BUTTON_INVOICE, &CFileBrowserDlg::OnBnClickedButtonInvoice)
	ON_BN_CLICKED(IDC_BUTTON_INVOICE_ITEM, &CFileBrowserDlg::OnBnClickedButtonInvoiceItem)
	ON_BN_CLICKED(IDOK, &CFileBrowserDlg::OnBnClickedOk)
END_MESSAGE_MAP()


// CFileBrowserDlg message handlers


void CFileBrowserDlg::OnBnClickedButtonCustomer()
{
	m_customerPath = getFileBrowsePath();
	activateButton();
	UpdateData(FALSE);
}


void CFileBrowserDlg::OnBnClickedButtonInvoice()
{
	m_invoicePath = getFileBrowsePath();
	activateButton();
	UpdateData(FALSE);
} 


void CFileBrowserDlg::OnBnClickedButtonInvoiceItem()
{
	m_invoiceItemPath = getFileBrowsePath();
	activateButton();
	UpdateData(FALSE);	
}


void CFileBrowserDlg::OnBnClickedOk()
{
	// TODO: Add your control notification handler code here

	CCSVReader reader(m_customerPath, m_invoicePath, m_invoiceItemPath);
	
	theApp.m_customerFileName = m_customerPath.Mid(m_customerPath.ReverseFind('\\') + 1);
	theApp.m_invoiceFileName = m_invoicePath.Mid(m_invoicePath.ReverseFind('\\') + 1);;
	theApp.m_invoiceItemFileName = m_invoiceItemPath.Mid(m_invoiceItemPath.ReverseFind('\\') + 1);

	reader.ReadCustomerCSVFile();
	reader.ReadInvoiceCSVFile();
	reader.ReadInvoiceItemCSVFile();

	if (!m_fileTool)
	{
		m_fileTool = new CDreamCandies_File_ToolDlg(this);
		m_fileTool->Create(CDreamCandies_File_ToolDlg::IDD, this);
	}
	m_fileTool->UpdateCustomerData();
	m_fileTool->ShowWindow(TRUE);
}

CString CFileBrowserDlg::getFileBrowsePath()
{
	CString filePath = L"";
	CFileDialog dlgFile(TRUE, NULL, NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, NULL, NULL, 0);
	dlgFile.m_ofn.Flags |= (OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT);
	CString strFilter = L"";
	strFilter += "CSV Files";
	strFilter += (TCHAR)'\0';
	strFilter += _T("*.CSV");
	strFilter += (TCHAR)'\0';
	dlgFile.m_ofn.nMaxCustFilter++;

	dlgFile.m_ofn.lpstrFilter = strFilter;
	dlgFile.m_ofn.lpstrTitle = L"Open";

	CString fileName = L"";
	dlgFile.m_ofn.lpstrFile = fileName.GetBuffer(_MAX_PATH);


	INT_PTR nResult = dlgFile.DoModal();
	if (nResult == IDOK)
	{
		filePath = dlgFile.GetPathName();
		int isFileExist = PathFileExists(filePath);
		if (isFileExist)
		{
		}
		else
		{
			AfxMessageBox(L"File does not exist");
		}
	}
	return filePath;
}

void CFileBrowserDlg::activateButton()
{
	if (!m_customerPath.IsEmpty() && !m_invoicePath.IsEmpty() && !m_invoiceItemPath.IsEmpty())
		GetDlgItem(IDOK)->EnableWindow(TRUE);
	else
		GetDlgItem(IDOK)->EnableWindow(FALSE);
}


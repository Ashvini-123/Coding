#include "stdafx.h"
#include "CSVReader.h"
#include <vector>
#include "Customer.h"
#include <algorithm>
#include "DreamCandies_File_Tool.h"
#include "Invoice.h"
#include "InvoiceItem.h"


CCSVReader::CCSVReader(CString customerPath, CString invoicePath, CString invoiceItemPath)
{
	m_customerPath = customerPath;
	m_invoicePath = invoicePath;
	m_invoiceItemPath = invoiceItemPath;
	m_customerIndex = -1;
	m_invoiceIndex = -1;
}

CCSVReader::~CCSVReader()
{
}


void CCSVReader::ReadCustomerCSVFile()
{
	FILE* filePtr = nullptr;
	std::wstring abc = m_customerPath;
	const wchar_t* tempPath = abc.c_str();

	// First read customer file
	_wfopen_s(&filePtr, tempPath, L"r");
	std::vector<Customer*> customerData;

	if (filePtr)
	{
		bool eof = false;
		while (1)
		{
			char a = fgetc(filePtr);
			if (a == '\n' || a == '�')
			{
				break;
			}
		}

		while (1)
		{
			size_t strCnt = 0;
			while (1)
			{
				char a;
				std::string str;
				int i = 0;
				bool isEOL = false;

				while (1)
				{
					a = fgetc(filePtr);
					std::string temp(1, a);
					if (a == ',' || a == '\t')
						break;

					else if (a == '\"')
						continue;

					else if (a == '\n' || a == '�')
					{
						isEOL = true;
						if (a == '�')
							eof = true;
						break;
					}

					str += temp;
				}

				strCnt++;
				if (strCnt != 0)
				{
					std::string temp = str;
					if (strCnt == 1)
					{
						m_pCustomer = new Customer();
						m_pCustomer->SetCustomerCode(temp);
					}
					else if (strCnt == 2)
					{
						m_pCustomer->SetFirstName(temp);
					}
					else if (strCnt == 3)
					{
						m_pCustomer->SetLastName(temp);
						if (isEOL == true)
						{
							customerData.push_back(m_pCustomer);
							isEOL = false;
							strCnt = 0;
						}
					}
				}
				if (eof)
					break;
			}
			if (eof)
				break;
		}
		fclose(filePtr);
	}
	theApp.SetCustomers(customerData);
}

void CCSVReader::ReadInvoiceCSVFile()
{
	FILE* filePtr = nullptr;
	std::wstring abc = m_invoicePath;
	const wchar_t* tempPath = abc.c_str();

	// First read customer file
	_wfopen_s(&filePtr, tempPath, L"r");
	std::vector<Invoice*> pInvoiceData;

	if (filePtr)
	{
		bool eof = false;
		while (1)
		{
			char a = fgetc(filePtr);
			if (a == '\n' || a == '�')
			{
				break;
			}
		}

		std::string customerCode = "";
		while (1)
		{
			size_t strCnt = 0;
			bool isExist = false;
			while (1)
			{
				char a;
				std::string str;
				int i = 0;
				bool isEOL = false;
				int index = -1;
				
				while (1)
				{
					a = fgetc(filePtr);
					std::string temp(1, a);
					if (a == ',' || a == '\t')
						break;

					else if (a == '\"')
						continue;

					else if (a == '\n')
					{
						isEOL = true;
						break;
					}
					if (a == '�')
					{
						eof = true;
						break;
					}
					str += temp;
				}

				if (str != "")
				{
					strCnt++;

					if (strCnt == 1)
					{
						isExist = theApp.CheckIsCustomerExist(str, m_customerIndex);
					}
					else if (isExist)
					{
						if (strCnt == 2)
						{
							m_pInvoice = new Invoice();
							m_pInvoice->SetInvoiceCode(str);
						}
						else if (strCnt == 3)
						{
							float amount = ::atof(str.c_str());
							m_pInvoice->SetAmount(amount);
						}
						else if (strCnt == 4)
						{
							m_pInvoice->SetDate(str);
							theApp.SetInvoice(m_pInvoice, m_customerIndex);
							strCnt = 0;
						}
					}
				}
				if (eof)
					break;
			}
			if (eof)
				break;
		}
	}
	fclose(filePtr);
}

void CCSVReader::ReadInvoiceItemCSVFile()
{
	FILE* filePtr = nullptr;
	std::wstring abc = m_invoiceItemPath;
	const wchar_t* tempPath = abc.c_str();

	// First read customer file
	_wfopen_s(&filePtr, tempPath, L"r");
	std::vector<Invoice*> pInvoiceData;

	if (filePtr)
	{
		bool eof = false;
		while (1)
		{
			char a = fgetc(filePtr);
			if (a == '\n' || a == '�')
			{
				break;
			}
		}

		std::string customerCode = "";
		while (1)
		{
			size_t strCnt = 0;
			bool isExist = false;
			while (1)
			{
				char a;
				std::string str;
				int i = 0;
				bool isEOL = false;
				int index = -1;

				while (1)
				{
					a = fgetc(filePtr);
					std::string temp(1, a);
					if (a == ',' || a == '\t')
						break;

					else if (a == '\"')
						continue;

					else if (a == '\n')
					{
						isEOL = true;
						break;
					}
					if (a == '�')
					{
						eof = true;
						break;
					}
					str += temp;
				}

				if (str != "")
				{
					strCnt++;

					if (strCnt == 1)
					{
						isExist = theApp.CheckIsInvoiceExist(str, m_invoiceIndex, m_customerIndex);
					}
					else if (isExist)
					{
						if (strCnt == 2)
						{
							m_pInvoiceItem = new InvoiceItem();
							m_pInvoiceItem->SetItemCode(str);
						}
						else if (strCnt == 3)
						{
							float amount = ::atof(str.c_str());
							m_pInvoiceItem->SetAmount(amount);
						}
						else if (strCnt == 4)
						{
							int quantity = ::atoi(str.c_str());
							m_pInvoiceItem->SetQuantity(quantity);

							theApp.SetInvoiceItem(m_pInvoiceItem, m_invoiceIndex, m_customerIndex);
							strCnt = 0;
						}
					}
				}
				if (eof)
					break;
			}
			if (eof)
				break;
		}
	}
	fclose(filePtr);
}



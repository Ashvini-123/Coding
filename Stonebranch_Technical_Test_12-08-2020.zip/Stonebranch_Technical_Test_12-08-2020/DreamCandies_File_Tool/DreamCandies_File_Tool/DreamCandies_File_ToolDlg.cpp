
// DreamCandies_File_ToolDlg.cpp : implementation file
//

#include "stdafx.h"
#include "DreamCandies_File_Tool.h"
#include "DreamCandies_File_ToolDlg.h"
#include "afxdialogex.h"
#include "CSVReader.h"
#include "CGridRowTraitXP.h"
#include "CGridColumnTraitImage.h"
#include "CGridColumnTraitEdit.h"
#include "CGridColumnTraitText.h"
#include "Customer.h"
#include "CSVWriter.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

	// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CDreamCandies_File_ToolDlg dialog



CDreamCandies_File_ToolDlg::CDreamCandies_File_ToolDlg(CWnd* pParent /*=NULL*/)
: CDialogEx(CDreamCandies_File_ToolDlg::IDD, pParent)
, m_folderPath(_T(""))
, m_sampleCount(1)
, m_totalItemCount(0)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_headerFont = new CFont();
}

void CDreamCandies_File_ToolDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_CUSTOMER_LIST, m_customerListCtrl);
	DDX_Text(pDX, IDC_EDIT_FOLDER_PATH, m_folderPath);
	DDX_Text(pDX, IDC_EDIT_SAMPLE, m_sampleCount);
	DDV_MinMaxInt(pDX, m_sampleCount, 1, 10000000);
	DDX_Text(pDX, IDC_STATIC_TOTAL_COUNT, m_totalItemCount);
}

BEGIN_MESSAGE_MAP(CDreamCandies_File_ToolDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDOK, &CDreamCandies_File_ToolDlg::OnBnClickedOk)
	ON_BN_CLICKED(IDC_BUTTON_BROWSE, &CDreamCandies_File_ToolDlg::OnBnClickedButtonBrowse)
	ON_EN_CHANGE(IDC_EDIT_SAMPLE, &CDreamCandies_File_ToolDlg::OnEnChangeEditSample)
END_MESSAGE_MAP()


// CDreamCandies_File_ToolDlg message handlers

BOOL CDreamCandies_File_ToolDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	initializeColumnList();

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CDreamCandies_File_ToolDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CDreamCandies_File_ToolDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CDreamCandies_File_ToolDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



void CDreamCandies_File_ToolDlg::OnBnClickedOk()
{
	CWaitCursor cursur;
	CCSVWriter writer(m_folderPath, m_sampleCount);
	writer.WriteData();
	cursur.Restore();
	AfxMessageBox(L"All data exported to selected folder location");
}


void CDreamCandies_File_ToolDlg::initializeColumnList()
{
	m_customerListCtrl.SetCellMargin(1.2);
	CGridRowTraitXP *pRowTrait = new CGridRowTraitXP;
	m_customerListCtrl.SetDefaultRowTrait(pRowTrait);
	m_customerListCtrl.EnableVisualStyles(true);

	CFont *normalFont = GetFont();
	LOGFONT lf;
	normalFont->GetLogFont(&lf);
	lf.lfWeight = FW_BOLD;

	m_headerFont->CreateFontIndirect(&lf);
	m_customerListCtrl.GetHeaderCtrl()->SetFont(m_headerFont, 1);

	m_customerListCtrl.InsertHiddenLabelColumn();
	m_customerListCtrl.InsertColumn(1, L"Customer Code", LVCFMT_LEFT, 250);
	m_customerListCtrl.InsertColumn(2, L"FirstName", LVCFMT_LEFT, 150);
	m_customerListCtrl.InsertColumn(3, L"LastName", LVCFMT_LEFT, 150);

	
}

void CDreamCandies_File_ToolDlg::UpdateCustomerData()
{
	if (m_customerListCtrl.GetSafeHwnd())
	{
		m_customerListCtrl.DeleteAllItems();

		std::vector<Customer*> pcustomerData;
		theApp.GetCustomerData(pcustomerData);

		for (int jCount = 0; jCount < pcustomerData.size(); ++jCount)
		{ 
			std::string customerCode = pcustomerData[jCount]->GetCustomerCode();
			CString customerCodeStr = CString(customerCode.c_str(), (int)customerCode.length());

			std::string firstName = pcustomerData[jCount]->GetFirstName();
			CString firstNameStr = CString(firstName.c_str(), (int)firstName.length());

			std::string lastName = pcustomerData[jCount]->GetLastName();
			CString lastNameStr = CString(lastName.c_str(), (int)lastName.length());

			int index = m_customerListCtrl.GetItemCount();
			m_customerListCtrl.InsertItem(index, CA2T(""));

			m_customerListCtrl.SetItemText(index, 1, customerCodeStr);
			m_customerListCtrl.SetItemText(index, 2, firstNameStr);
			m_customerListCtrl.SetItemText(index, 3, lastNameStr);
			//m_customerListCtrl.SetCellImage(index, 4, 1);
			m_customerListCtrl.EnsureVisible(index, TRUE);
		}
		m_totalItemCount = m_customerListCtrl.GetItemCount();
		UpdateData(FALSE);
	}

}

void CDreamCandies_File_ToolDlg::OnBnClickedButtonBrowse()
{
	CFolderPickerDialog dlg;
	dlg.m_ofn.lpstrTitle = _T("Select Folder");
	if (dlg.DoModal() == IDOK)
	{
		m_folderPath = dlg.GetPathName();
		std::string folderPath(CW2A(m_folderPath.GetString()));
		size_t length = folderPath.length();
		std::string temp("\\");
		if (folderPath[length - 1] != temp[0])
			folderPath.append("\\");
		m_folderPath = folderPath.c_str();
	}

	if (m_sampleCount <= 0 || m_folderPath.IsEmpty())
		GetDlgItem(IDOK)->EnableWindow(FALSE);
	else
		GetDlgItem(IDOK)->EnableWindow(TRUE);

	UpdateData(FALSE);
}



void CDreamCandies_File_ToolDlg::OnEnChangeEditSample()
{
	UpdateData(TRUE);
	
	if (m_sampleCount > m_totalItemCount)
	{
		AfxMessageBox(L"Invalid Number");
		m_sampleCount = 1;
	}


	if (m_sampleCount <= 0 || m_folderPath.IsEmpty())
		GetDlgItem(IDOK)->EnableWindow(FALSE);
	else
		GetDlgItem(IDOK)->EnableWindow(TRUE);

	UpdateData(FALSE);
}

#include "stdafx.h"
#include "CSVWriter.h"
#include "Customer.h"
#include <algorithm>
#include "DreamCandies_File_Tool.h"
#include <fstream>
#include "Invoice.h"
#include "InvoiceItem.h"
#include <vector>

CCSVWriter::CCSVWriter(CString folderPath, const int preSelectCount)
{
	std::vector<Customer*> customers;
	theApp.GetCustomerData(customers);

	std::vector<Customer*> tempData;
	tempData = customers;
	std::random_shuffle(tempData.begin(), tempData.end());
	m_customers.resize(preSelectCount);
	std::copy(tempData.begin(), tempData.begin() + preSelectCount, m_customers.begin());
	
	m_folderPath = folderPath;
	m_preSelectData = preSelectCount;
	
}


CCSVWriter::~CCSVWriter()
{
	m_customers.clear();
}

void CCSVWriter::writeCustomerSampleFile()
{
	std::string folderPath(CW2A(m_folderPath.GetString()));
	std::string fileName(CW2A(theApp.m_customerFileName.GetString()));

	std::ofstream write;
	write.open(folderPath + fileName);
	if (!write.is_open())
		return;
	write << "\"CUSTOMER_CODE\"" << "," << "\"FIRSTNAME\"" << "," << "\"LASTNAME\"" << "\n";
	for (int iCount = 0; iCount < m_customers.size(); ++iCount)
	{
		std::string customerCode = "\"" + m_customers[iCount]->GetCustomerCode() + "\"";
		std::string firstName = "\"" + m_customers[iCount]->GetFirstName() + "\"";
		std::string lastName = "\"" + m_customers[iCount]->GetLastName() + "\"";

		write << customerCode << "," << firstName << "," << lastName << "\n";
	}

	write.close();

}
void CCSVWriter::writeInvoiceFile()
{
	std::string folderPath(CW2A(m_folderPath.GetString()));
	std::string fileName(CW2A(theApp.m_invoiceFileName.GetString()));
	std::ofstream write;
	write.open(folderPath + fileName);
	if (!write.is_open())
		return;

	write << "\"CUSTOMER_CODE\"" << "," << "\"INVOICE_CODE\"" << "," << "\"AMOUNT\"" << "," << "\"DATE\"" << "\n";

	for (int iCount = 0; iCount < m_customers.size(); ++iCount)
	{
		std::string customerCode = "\"" + m_customers[iCount]->GetCustomerCode() + "\"";
		std::vector<Invoice*> invoiceVect;
		m_customers[iCount]->GetInvoiceVect(invoiceVect);

		for (int jCount = 0; jCount < invoiceVect.size(); ++jCount)
		{
			std::string invoiceCode = "\"" + invoiceVect[jCount]->GetInvoiceCode() + "\"";
			float amountVal = invoiceVect[jCount]->GetAmount();
			CString amountStr;
			amountStr.Format(L"\"%.2f\"", amountVal);
			std::string amount(CW2A(amountStr.GetString()));

			std::string date = "\"" + invoiceVect[jCount]->GetDate() + "\"";

			write << customerCode << "," << invoiceCode << "," << amount << "," << date << "\n";
		}
	}
	write.close();
}

void CCSVWriter::writeInvoiceItemFile()
{
	std::string folderPath(CW2A(m_folderPath.GetString()));
	std::string fileName(CW2A(theApp.m_invoiceItemFileName.GetString()));

	std::ofstream write;
	write.open(folderPath + fileName);
	if (!write.is_open())
		return;

	write << "\"INVOICE_CODE\"" << "," << "\"ITEM_CODE\"" << "," << "\"AMOUNT\"" << "," <<"\"QUANTITY\"" << "\n";

	for (int iCount = 0; iCount < m_customers.size(); ++iCount)
	{
		std::vector<Invoice*> invoiceVect;
		m_customers[iCount]->GetInvoiceVect(invoiceVect);

		for (int jCount = 0; jCount < invoiceVect.size(); ++jCount)
		{
			std::string invoiceCode = "\"" + invoiceVect[jCount]->GetInvoiceCode() + "\"";

			std::vector<InvoiceItem*> pInvoiceItems;
			invoiceVect[jCount]->GetInvoiceItems(pInvoiceItems);

			for (int kCount = 0; kCount < pInvoiceItems.size(); ++kCount)
			{
				std::string itemCode = "\"" + pInvoiceItems[kCount]->GetItemCode() + "\"";
				float amountVal = pInvoiceItems[kCount]->GetAmount();
				CString amountStr;
				amountStr.Format(L"\"%.2f\"", amountVal);
				std::string amount(CW2A(amountStr.GetString()));

				int quantityVal = pInvoiceItems[kCount]->GetAmount();
				CString quantityStr;
				quantityStr.Format(L"\"%d\"", quantityVal);
				std::string quantity(CW2A(quantityStr.GetString()));

				write << invoiceCode << "," << itemCode << "," << amount << "," << quantity << "\n";
			}
		}
	}
	write.close();
}

void CCSVWriter::WriteData()
{
	writeCustomerSampleFile();
	writeInvoiceFile();
	writeInvoiceItemFile();
}

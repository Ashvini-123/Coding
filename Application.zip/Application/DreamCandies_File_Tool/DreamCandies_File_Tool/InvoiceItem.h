#pragma once
#include <string>

class InvoiceItem
{
	std::string m_itemCode;
	float m_amount;
	int m_quantity;

public:
	InvoiceItem();
	~InvoiceItem();

	void SetItemCode(std::string itemCode);
	void SetAmount(float amount);
	void SetQuantity(int quantity);

	std::string GetItemCode()const;
	float GetAmount()const;
	int GetQuantity()const;
};


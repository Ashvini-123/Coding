#pragma once


// CFileBrowserDlg dialog
class CDreamCandies_File_ToolDlg;
class CFileBrowserDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CFileBrowserDlg)
	CDreamCandies_File_ToolDlg *m_fileTool;
public:
	CFileBrowserDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CFileBrowserDlg();

// Dialog Data
	enum { IDD = IDD_FILE_BROWSER };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButtonCustomer();
	afx_msg void OnBnClickedButtonInvoice();
	afx_msg void OnBnClickedButtonInvoiceItem();
	afx_msg void OnBnClickedOk();

private:
	CString m_customerPath;
	CString m_invoicePath;
	CString m_invoiceItemPath;
	void activateButton();
	CString getFileBrowsePath();
};

#include "stdafx.h"
#include "Customer.h"
#include "Invoice.h"


Customer::Customer()
{
	m_customerCode = "";
	m_firstName = "";
	m_lastName = "";
	m_invoiceVect.clear();
}

Customer::~Customer()
{

}

void Customer::SetCustomerCode(std::string customerCode)
{
	m_customerCode = customerCode;
}

void Customer::SetFirstName(std::string firstName)
{
	m_firstName = firstName;
}

void Customer::SetLastName(std::string lastName)
{
	m_lastName = lastName;
}

std::string Customer::GetCustomerCode()const
{
	return m_customerCode;
}

void Customer::AddInvoice(Invoice* pInvoice)
{
	if (pInvoice)
	{
		m_invoiceVect.push_back(pInvoice);
	}
}

void Customer::GetInvoiceVect(std::vector<Invoice*>& invoiceVect)
{
	invoiceVect = m_invoiceVect;
}

std::string Customer::GetFirstName()
{
	return m_firstName;
}

std::string Customer::GetLastName()
{
	return m_lastName;
}
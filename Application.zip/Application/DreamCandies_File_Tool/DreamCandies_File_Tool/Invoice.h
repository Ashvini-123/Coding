#pragma once
#include <string>
#include <vector>
#include "InvoiceItem.h"


class Invoice
{
	std::string m_invoiceCode;
	float m_amount;
	std::string m_date;
	std::vector<InvoiceItem*>m_invoiceItemVect;

public:
	Invoice();
	~Invoice();

	void SetInvoiceCode(std::string invoiceCode);
	void SetAmount(float amount);
	void SetDate(std::string m_date);
	std::string GetInvoiceCode()const;
	void AddInvoiceItem(InvoiceItem* pAddInvoiceItem);
	float GetAmount()const;
	std::string GetDate()const;
	void GetInvoiceItems(std::vector<InvoiceItem*>& invoiceItemVect);
};


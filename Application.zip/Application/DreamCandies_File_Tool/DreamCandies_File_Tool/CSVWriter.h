#pragma once
#include <vector>
class Customer;
class CCSVWriter
{
	std::vector<Customer*> m_customers;
	CString m_folderPath;
	int m_preSelectData = 0;
	void writeCustomerSampleFile();
	void writeInvoiceFile();
	void writeInvoiceItemFile();
public:
	CCSVWriter(CString folderPath, const int preSelectCount);
	~CCSVWriter();
	void WriteData();
};


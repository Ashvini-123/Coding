#include "stdafx.h"
#include "InvoiceItem.h"
#include <string>

InvoiceItem::InvoiceItem()
{
	m_itemCode = "";
	m_amount = -1.0;
	m_quantity = 0;
}


InvoiceItem::~InvoiceItem()
{
}


void InvoiceItem::SetItemCode(std::string itemCode)
{
	m_itemCode = itemCode;
}
void InvoiceItem::SetAmount(float amount)
{
	m_amount = amount;
}
void InvoiceItem::SetQuantity(int quantity)
{
	m_quantity = quantity;
}

std::string InvoiceItem::GetItemCode()const
{
	return m_itemCode;
}
float InvoiceItem::GetAmount()const
{
	return m_amount;
}
int InvoiceItem::GetQuantity()const
{
	return m_quantity;
}
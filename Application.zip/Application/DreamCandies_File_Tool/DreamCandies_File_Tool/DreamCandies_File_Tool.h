
// DreamCandies_File_Tool.h : main header file for the PROJECT_NAME application
//

#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"		// main symbols
#include <vector>

// CDreamCandies_File_ToolApp:
// See DreamCandies_File_Tool.cpp for the implementation of this class
//
class Customer;
class Invoice;
class InvoiceItem;
class CDreamCandies_File_ToolApp : public CWinApp
{
	std::vector<Customer*> m_customerData;
	
public:
	CString	m_customerFileName;
	CString	m_invoiceFileName;
	CString	m_invoiceItemFileName;

	CDreamCandies_File_ToolApp();

// Overrides
public:
	virtual BOOL InitInstance();
	void SetCustomers(std::vector<Customer*>& customerData);
	bool CheckIsCustomerExist(std::string customerCode, int& index);
	void SetInvoice(Invoice* pInvoiceCode, int& index);
	bool CheckIsInvoiceExist(std::string invoiceCode, int& invoiceIndex, int& customerIndex);
	void SetInvoiceItem(InvoiceItem* pInvoiceItem, int& invoiceIndex, int& customerIndex);
	void GetCustomerData(std::vector<Customer*>& customerData);
// Implementation

	DECLARE_MESSAGE_MAP()
};

extern CDreamCandies_File_ToolApp theApp;


#include "stdafx.h"
#include "Invoice.h"


Invoice::Invoice()
{
	m_invoiceCode = "";
	m_amount = -1.0;
	m_invoiceItemVect.clear();
}

Invoice::~Invoice()
{

}

void Invoice::SetInvoiceCode(std::string invoiceCode)
{
	m_invoiceCode = invoiceCode;
}

void Invoice::SetAmount(float amount)
{
	m_amount = amount;
}

void Invoice::SetDate(std::string date)
{
	m_date = date;
}

std::string Invoice::GetInvoiceCode()const
{
	return m_invoiceCode;
}

void Invoice::AddInvoiceItem(InvoiceItem* pAddInvoiceItem)
{
	m_invoiceItemVect.push_back(pAddInvoiceItem);
}

float Invoice::GetAmount()const
{
	return m_amount;
}
std::string Invoice::GetDate()const
{
	return m_date;
}

void Invoice::GetInvoiceItems(std::vector<InvoiceItem*>& invoiceItemVect)
{
	invoiceItemVect = m_invoiceItemVect;
}